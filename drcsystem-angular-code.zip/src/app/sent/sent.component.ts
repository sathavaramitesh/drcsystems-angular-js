import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { HelperService } from '../services/helper.service';
import { HomeService } from '../services/home.service';

@Component({
  selector: 'app-sent',
  templateUrl: './sent.component.html',
  styleUrls: ['./sent.component.scss'],
})
export class SentComponent implements OnInit {
  friendList: any = [];
  submitted = false;
  composeForm: FormGroup;
  modalRef: BsModalRef;
  viewId: any;
  viewObject: any = {};
  constructor(
    private home: HomeService,
    private modalService: BsModalService,
    public helper: HelperService,
    private router: Router,
    private fb: FormBuilder
  ) {
    this.getRequest();
  }

  ngOnInit(): void {
  }

  getRequest() {
    this.home.requestList().subscribe(
      (res: any) => {
        this.friendList = res.data;
      },
      (err) => {
        console.log(err);
      }
    );
  }

  accept(id) {
    this.home.acceptFriendRequest(id).subscribe(
      (res: any) => {
      
        this.helper.showSuccess(res.msg);
        this.getRequest();
      },
      (err) => {
        console.log(err);
      }
    );
  }
}
