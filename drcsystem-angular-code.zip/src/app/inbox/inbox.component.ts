import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { HelperService } from '../services/helper.service';
import { HomeService } from '../services/home.service';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss'],
})
export class InboxComponent implements OnInit {
  userData: any = [];
  constructor(
    private home: HomeService,
    public helper: HelperService,
  ) {
    this.getInbox();
  }

  ngOnInit(): void {
  }

  getInbox() {
    this.home.userList().subscribe(
      (res: any) => {
        this.userData = res.data;
      },
      (err) => {
        console.log(err);
      }
    );
  }

  sendRequest(id) {
    this.home.sendFriendRequest(id).subscribe(
      (res: any) => {
      
        this.helper.showSuccess(res.msg);
        this.getInbox();
      },
      (err) => {
        console.log(err);
      }
    );
    
  }
  
}
