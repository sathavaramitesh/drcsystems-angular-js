import { Component, OnInit } from '@angular/core';
import { HelperService } from '../services/helper.service';
import { Router, ActivatedRoute } from '@angular/router';
import { HomeService } from '../services/home.service';

@Component({
  selector: 'app-chat-history',
  templateUrl: './chat-history.component.html',
  styleUrls: ['./chat-history.component.scss']
})
export class ChatHistoryComponent implements OnInit {
  public id: number;
  chatHisory: any = {};
  userData;
  fullName;
  email;
  constructor(
    public helper: HelperService,
    private router: Router,
    private route: ActivatedRoute,
    private home: HomeService,
  ) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params.id;
    this.getChatHistory(this.id);
    this.userData = JSON.parse(localStorage.getItem('userData'));
  }

  getChatHistory(id){
    this.home.chatHistory(id).subscribe(
      (res: any) => {
        this.chatHisory = res.data;
      },
      (err) => {
        console.log(err);
      }
    );
  }

  logout() {
    this.helper.delAllPREF();
    this.router.navigate(['/login']);
  }

}
